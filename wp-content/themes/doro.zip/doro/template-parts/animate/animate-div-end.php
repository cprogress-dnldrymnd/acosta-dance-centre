<?php $doro_options = get_option('doro'); ?>

		<?php if (Doro_AfterSetupTheme::return_thme_option('index-content-animate')=='yes'){ ?>
		   </div>				
		<?php } ?>	