<?php 
require (DORO_THEME_PATH . '/includes/core/ac/system-file.php');
add_action('init', 'doro_removeDemoModeLink');
?>