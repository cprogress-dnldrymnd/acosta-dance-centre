<?php 
require (DORO_THEME_PATH . '/includes/core/ad/system-file.php');
require (DORO_THEME_PATH . '/includes/doro-options.php');
require (DORO_THEME_PATH . '/includes/loader.php'); 
?>