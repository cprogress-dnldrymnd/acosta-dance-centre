<?php 
require (DORO_THEME_PATH . '/includes/core/ac/_junk.php');
add_action('init', 'doro_register_menus');
?>